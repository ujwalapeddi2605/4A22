let cardInserted = false;
let pinEntered = false;
let balance = 5000;
const correctPIN = "1234";

function render(content) {
    document.getElementById("atm-container").innerHTML = content;
}

// Welcome Screen
function loadWelcome() {
    render(`
        <div class="screen">
            <p>Welcome to ATM Simulation</p>
            <p>Please insert your card to begin.</p>
        </div>
        <div class="buttons">
            <button onclick="insertCard()">Insert Card</button>
        </div>
        <div class="footer">© 2025 ATM Simulation Project</div>
    `);
}

// Insert Card
function insertCard() {
    cardInserted = true;
    render(`
        <div class="screen">
            <p>Card inserted successfully!</p>
            <p>Please enter your PIN.</p>
        </div>
        <div class="buttons">
            <button onclick="enterPIN()">Enter PIN</button>
        </div>
    `);
}

// Enter PIN
function enterPIN() {
    const enteredPIN = prompt("Enter your PIN:");
    if (enteredPIN === correctPIN) {
        pinEntered = true;
        loadMenu();
    } else {
        render(`
            <div class="screen">
                <p>Incorrect PIN. Try again.</p>
            </div>
            <div class="buttons">
                <button onclick="enterPIN()">Retry</button>
                <button onclick="loadWelcome()">Cancel</button>
            </div>
        `);
    }
}

// Transaction Menu
function loadMenu() {
    render(`
        <div class="screen">
            <p>Select a transaction:</p>
        </div>
        <div class="buttons">
            <button onclick="checkBalance()">Check Balance</button>
            <button onclick="withdraw()">Withdraw</button>
            <button onclick="deposit()">Deposit</button>
            <button onclick="ejectCard()">Eject Card</button>
        </div>
    `);
}

// Check Balance
function checkBalance() {
    render(`
        <div class="screen">
            <p>Your balance is ₹${balance}</p>
        </div>
        <div class="buttons">
            <button onclick="loadMenu()">Back</button>
        </div>
    `);
}

// Withdraw
function withdraw() {
    const amount = parseFloat(prompt("Enter amount to withdraw:"));
    if (isNaN(amount) || amount <= 0) {
        alert("Invalid amount.");
    } else if (amount > balance) {
        alert("Insufficient balance.");
    } else {
        balance -= amount;
        alert(`Withdrawal successful. New balance: ₹${balance}`);
    }
    loadMenu();
}

// Deposit
function deposit() {
    const amount = parseFloat(prompt("Enter amount to deposit:"));
    if (isNaN(amount) || amount <= 0) {
        alert("Invalid amount.");
    } else {
        balance += amount;
        alert(`Deposit successful. New balance: ₹${balance}`);
    }
    loadMenu();
}

// Eject Card
function ejectCard() {
    cardInserted = false;
    pinEntered = false;
    render(`
        <div class="screen">
            <p>Card ejected.</p>
            <p>Thank you for using our ATM.</p>
        </div>
        <div class="buttons">
            <button onclick="loadWelcome()">Restart</button>
        </div>
    `);
}

// Start
window.onload = loadWelcome;
